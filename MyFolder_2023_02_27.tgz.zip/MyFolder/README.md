Folder Compression Tool
This Python script provides a simple tool to compress folders into ZIP, TAR, or TGZ archive formats.

How to Run
Clone the Repository:

Clone this repository to your local machine using the following command:

bash
Copy code
git clone https://github.com/yourusername/folder-compression-tool.git
Navigate to the Directory:

bash
Copy code
cd folder-compression-tool
Install Requirements (if necessary):

Ensure you have Python installed on your system. This script is compatible with Python 3.

Run the Script:

Execute the script by running the following command:

Copy code
python compress_folder.py
Follow the Prompts:

Enter the path of the folder you want to compress when prompted.
Choose the desired compression type (zip, tar, or tgz) from the available options.
Compression Output:

Upon successful compression, the script will generate a compressed file with the format: foldername_date.zip or foldername_date.tar or foldername_date.tgz, depending on the selected compression type.

View the Compressed File:

Locate the compressed file in the same directory where the script was executed.

Notes
Ensure that you have necessary permissions to read the folder you want to compress and write the compressed file to the directory.
This script does not handle encryption or password protection for compressed files.
For any issues or suggestions, please feel free to open an issue or pull request in the GitHub repository.
