# The following code defines functions to compress folders using various compression types.

import os
import shutil
import tarfile
import zipfile

# Function to compress a folder based on the specified compression type.
def compress_folder(folder_path, compress_type):
    # Extract the name of the folder from its path.
    folder_name = os.path.basename(folder_path)
    # Generate the output filename based on the current date and compression type.
    output_filename = f"{folder_name}_{get_current_date()}.{compress_type}"
    try:
        # Compress the folder based on the specified compression type.
        if compress_type == 'zip':
            with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # Walk through the folder and add its files to the ZIP archive.
                for root, dirs, files in os.walk(folder_path):
                    for file in files:
                        zipf.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), folder_path))
            print(f"Folder '{folder_name}' compressed successfully as '{output_filename}'.")
        elif compress_type == 'tar':
            with tarfile.open(output_filename, 'w') as tarf:
                # Add the entire folder to the TAR archive.
                tarf.add(folder_path, arcname=os.path.basename(folder_path))
            print(f"Folder '{folder_name}' compressed successfully as '{output_filename}'.")
        elif compress_type == 'tgz':
            with tarfile.open(output_filename, 'w:gz') as tarf:
                # Add the entire folder to the TAR archive and compress using gzip.
                tarf.add(folder_path, arcname=os.path.basename(folder_path))
            print(f"Folder '{folder_name}' compressed successfully as '{output_filename}'.")
        else:
            print("Unsupported compression type.")
    except Exception as e:
        print(f"Compression failed: {e}")

# Function to get the current date in the format YYYY_MM_DD.
def get_current_date():
    import datetime
    today = datetime.date.today()
    return today.strftime("%Y_%m_%d")

# Main function to interact with the user and compress the specified folder.
def main():
    # Prompt the user to enter the path of the folder to compress.
    folder_path = input("Enter the path of the folder to compress: ").strip()
    # Check if the specified folder exists.
    if not os.path.exists(folder_path):
        print("Folder does not exist.")
        return

    # Display the available compression types to the user.
    print("Available compressed file types:")
    print("1. zip")
    print("2. tar")
    print("3. tgz")

    # Prompt the user to select the desired compression type.
    compress_type = input("Select the desired compressed file type: ").strip().lower()

    # Check if the specified compression type is valid.
    if compress_type not in ['zip', 'tar', 'tgz']:
        print("Invalid compression type.")
        return

    # Compress the specified folder using the selected compression type.
    compress_folder(folder_path, compress_type)

# Entry point of the program.
if __name__ == "__main__":
    main()
